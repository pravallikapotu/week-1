import java.util.Arrays;

public class SearchFunctions {

    // Linear Search
    public static int linearSearch(Product[] products, String targetProductName) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductName().equals(targetProductName)) {
                return i; // Return the index of the found product
            }
        }
        return -1; // Return -1 if the product is not found
    }

    // Binary Search
    public static int binarySearch(Product[] products, String targetProductName) {
        int left = 0;
        int right = products.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int compare = products[mid].getProductName().compareTo(targetProductName);

            if (compare == 0) {
                return mid; // Return the index of the found product
            } else if (compare < 0) {
                left = mid + 1; // Search in the right half
            } else {
                right = mid - 1; // Search in the left half
            }
        }
        return -1; // Return -1 if the product is not found
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Phone", "Electronics"),
            new Product("3", "Shirt", "Clothing"),
            new Product("4", "Shoes", "Footwear"),
            new Product("5", "Watch", "Accessories")
        };

        // For binary search, the array should be sorted by productName
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));

        // Linear search
        int linearSearchResult = linearSearch(products, "Phone");
        System.out.println("Linear Search Result: " + linearSearchResult);

        // Binary search
        int binarySearchResult = binarySearch(products, "Phone");
        System.out.println("Binary Search Result: " + binarySearchResult);
    }
}
