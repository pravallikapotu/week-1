public class SinglyLinkedList {
    private Node head;

    public SinglyLinkedList() {
        this.head = null;
    }

    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public Task searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.data.taskId == taskId) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }

    public boolean deleteTask(int taskId) {
        Node current = head;
        Node previous = null;
        while (current != null) {
            if (current.data.taskId == taskId) {
                if (previous != null) {
                    previous.next = current.next;
                } else {
                    head = current.next;
                }
                return true;
            }
            previous = current;
            current = current.next;
        }
        return false;
    }

    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();
        taskList.addTask(new Task(1, "Design Database", "In Progress"));
        taskList.addTask(new Task(2, "Implement API", "Not Started"));
        taskList.addTask(new Task(3, "Write Documentation", "Completed"));

        // Searching for a task
        System.out.println(taskList.searchTask(2));  // Output: Task{taskId=2, taskName='Implement API', status='Not Started'}

        // Traversing tasks
        taskList.traverseTasks();

        // Deleting a task
        taskList.deleteTask(1);

        // Traversing again to see the change
        taskList.traverseTasks();
    }
}
