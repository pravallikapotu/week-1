package image;

public interface Image {
    void display();
}
