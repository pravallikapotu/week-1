import model.Student;
import view.StudentView;
import controller.StudentController;

public class MVCPatternExample {
    public static void main(String[] args) {
        Student student = new Student("Ram", 1, "A");

        StudentView studentView = new StudentView();

        StudentController studentController = new StudentController(student, studentView);

        studentController.updateView();

        studentController.setStudentName("Gowtham");
        studentController.setStudentGrade("A");
        studentController.updateView();
    }
}
