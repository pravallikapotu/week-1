package automation;

public interface Command {
    void execute();
}
