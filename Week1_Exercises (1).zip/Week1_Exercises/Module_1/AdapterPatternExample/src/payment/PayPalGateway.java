package payment;

public class PayPalGateway {
    public void makePayment(double amount) {
        System.out.println("Payment of Rs." + amount + " made through PayPal.");
    }
}
