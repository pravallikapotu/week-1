package payment;

public class StripeGateway {
    public void sendPayment(double amount) {
        System.out.println("Payment of Rs." + amount + " sent through Stripe.");
    }
}
