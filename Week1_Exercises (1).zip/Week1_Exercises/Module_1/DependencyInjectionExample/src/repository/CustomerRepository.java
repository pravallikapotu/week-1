package repository;

public interface CustomerRepository {
    String findCustomerById(int id);
}
