package notification;

public interface Notifier {
    void send(String message);
}
