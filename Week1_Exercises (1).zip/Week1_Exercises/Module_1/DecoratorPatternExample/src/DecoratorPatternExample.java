import notification.*;

public class DecoratorPatternExample {
    public static void main(String[] args) {
        Notifier notifier = new EmailNotifier();
        notifier.send("Hello!");

        System.out.println("\nAdding SMS notifier:");
        notifier = new SMSNotifierDecorator(notifier);
        notifier.send("Hello!");

        System.out.println("\nAdding Slack notifier:");
        notifier = new SlackNotifierDecorator(notifier);
        notifier.send("Hello!");
    }
}
